# Sample Streamlit app
import streamlit as st
st.title('Stock Tracker Dashboard')
